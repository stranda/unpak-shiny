make.numeric <- function(x) 
    {
        (
            as.numeric(as.character(x))
        )
    }

