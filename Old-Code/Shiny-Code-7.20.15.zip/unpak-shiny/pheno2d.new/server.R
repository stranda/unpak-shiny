#Partial Authorship by Nick Levitt
source("global.R")
library(ggplot2)

xy_range_str <- function(e) {
  if(is.null(e)) return("NULL")
  c(round(e$xmin, 2), round(e$xmax, 2), round(e$ymin, 2),round(e$ymax, 2))
}


makeHTMLtable <- function (df,session)
{
#   url.root <- "http://107.170.146.165:3838/findline/?line="
    url.root = paste0(sep = '',"http://",session$clientData$url_hostname,":",
                      session$clientData$url_port,'/findline/?line=')
    df$Accession <- paste0("<a href='",url.root, df$Accession, "' target='_blank'>",df$Accession,"</a>")
    cols <- dim(df)[2]
    rows <- dim(df)[1]
    for (j in 1:cols)
        {
            if (is.numeric(df[,j])) df[,j] <- as.character(round(df[,j],3))
            if (is.factor(df[,j])) df[,j] <- as.character(df[,j],3)
        }

    str <- "<table border = 1>"
    str <- paste0(str,"<tr><th>",paste(names(df),collapse="</th><th>"),"</tr>\n")
    for (i in 1:rows) {
      str <- paste0(str, "<tr><td>",paste(df[i,],collapse="</td><td>"),"</tr>\n")
    }
    str    
}


#### Define server logic required to summarize and view the selected dataset
shinyServer(function(input, output,session) {

  allData <- reactive({
    expt= " "
    treat=" "
    con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
    query <- paste("SELECT O.value, Pl.Accession_idAccession, T.name, E.name, F.Name, Ph.name FROM Observation O",
                   " JOIN IndividualPlant Pl ON O.IndividualPlant_idIndividualPlant = Pl.idIndividualPlant",
                   " JOIN Phenotype Ph ON O.Phenotype_idPhenotype = Ph.idPhenotype",
                   " JOIN Experiment E ON Pl.Experiment_idExperiment = E.idExperiment",
                   " JOIN Treatment T ON O.Treatment_idTreatment = T.idTreatment",
                   " JOIN Facility F ON Pl.Facility_idFacility = F.idFacility",
                   " WHERE",
                   expt,
                   treat,
                   " (Ph.name = '",input$pheno1,"'  OR Ph.name = '",input$pheno2,"')",
                   sep="")
    
    obstbl <- dbGetQuery(con,query)
    names(obstbl) <- c("value","Accession","treatment","experiment","facility","phenotype")
    if (dim(obstbl)[1]>0)
    {
      #             if (input$linemeans=="yes")
      if (TRUE)
      {
        ret <- with(obstbl,aggregate(cbind(value),by=list(Accession=Accession,Treatment=treatment,Experiment=experiment,Phenotype=phenotype),mean))
        ret <- ret[order(ret$value),c("value","Phenotype","Experiment","Treatment","Accession")]
      } else {
        ret <- obstbl
        ret$Treatment=ret$treatment
        ret$Experiment=ret$experiment
        ret$Facility=ret$facility
        ret$Phenotype=ret$phenotype
        ret <- ret[order(ret$Accession,ret$Experiment,ret$Treatment,ret$Facility),c("value","Phenotype","Treatment","Experiment","Facility","Accession")]
      }
      ret <- ret[complete.cases(ret),]
      
    } else {
      ret <- NULL  #data.frame(value=NA,Phenotype=NA,Treatment=NA,Experiment=NA,Accession=NA)
    }
    dbDisconnect(con)
    ret
  })
  
  values <- reactive({
   if (input$expt=="All"){expt=" "} else {expt=paste0(" E.name = '",input$expt,"' AND")}

   if (input$treat=="All"){treat=" "} else {treat=paste0(" T.name = '",input$treat,"' AND")}
     con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
     query <- paste("SELECT O.value, Pl.Accession_idAccession, T.name, E.name, F.Name, Ph.name FROM Observation O",
                    " JOIN IndividualPlant Pl ON O.IndividualPlant_idIndividualPlant = Pl.idIndividualPlant",
                    " JOIN Phenotype Ph ON O.Phenotype_idPhenotype = Ph.idPhenotype",
                    " JOIN Experiment E ON Pl.Experiment_idExperiment = E.idExperiment",
                    " JOIN Treatment T ON O.Treatment_idTreatment = T.idTreatment",
                    " JOIN Facility F ON Pl.Facility_idFacility = F.idFacility",
                    " WHERE",
                    expt,
                    treat,
                    " (Ph.name = '",input$pheno1,"'  OR Ph.name = '",input$pheno2,"')",
                    sep="")

     obstbl <- dbGetQuery(con,query)
     names(obstbl) <- c("value","Accession","treatment","experiment","facility","phenotype")
     if (dim(obstbl)[1]>0)
         {
#             if (input$linemeans=="yes")
             if (TRUE)
                 {
                     ret <- with(obstbl,aggregate(cbind(value),by=list(Accession=Accession,Treatment=treatment,Experiment=experiment,Phenotype=phenotype),mean))
                     ret <- ret[order(ret$value),c("value","Phenotype","Experiment","Treatment","Accession")]
                 } else {
                     ret <- obstbl
                     ret$Treatment=ret$treatment
                     ret$Experiment=ret$experiment
                     ret$Facility=ret$facility
                     ret$Phenotype=ret$phenotype
                     ret <- ret[order(ret$Accession,ret$Experiment,ret$Treatment,ret$Facility),c("value","Phenotype","Treatment","Experiment","Facility","Accession")]
                   }
             ret <- ret[complete.cases(ret),]

         } else {
             ret <- NULL  #data.frame(value=NA,Phenotype=NA,Treatment=NA,Experiment=NA,Accession=NA)
         }
     dbDisconnect(con)
     ret
  })
  
 output$msg <- renderText(
     {
         df <- values()
         if (dim(df[complete.cases(df),])[1]==0)
             {
                 paste("This combination of experiment (",input$expt,"), phenotypes (",input$pheno1,", ",input$pheno2,") and/or treatment (",input$treat,") does not exist in the database.  Try another combination")
             } else {
                 paste("Experiment (",input$expt,"), Phenotypes (",input$pheno1,", ",input$pheno2,"), Treatment (",input$treat,")")
             }
     })

output$experiments = renderUI({
  df = allData()
  
  var1 <- input$pheno1
  var2 <- input$pheno2
  names(df)[grep("Phenotype",names(df))] <- "variable"
  df <- cast(df)
  if (ncol(df) == 4) {
    poss = unique(df$Experiment)
  }
  else {
    indx1 = which(is.na(df[,4]))
    indx2 = which(is.na(df[,5]))
    df = df[-c(indx1,indx2),]
    poss = unique(df$Experiment)
  }
  
    selectInput("expt", "Choose an experiment:", 
                choices = c("All",sort(poss)))
  
  
}) 
 
output$urlText = renderText({
  df <- values()
  url.root = paste(sep = "", "HOST = ",session$clientData$url_hostname,": PORT = ",session$clientData$url_port,'/findline/?line=')

})

 output$scatter <- renderPlot(
     {

       
       df <- values()
       var1 <- input$pheno1
       var2 <- input$pheno2
       names(df)[grep("Phenotype",names(df))] <- "variable"
       df <- cast(df)  
       phenoOne = input$pheno1
       phenoTwo = input$pheno2
       xxx = ggplot(df,aes_string(x = phenoOne, y = phenoTwo))
       xxx + geom_point(aes(colour = Treatment)) + ggtitle('Phenotypic Distribution')


     })

output$displaySelectInfo <- renderText({
  selected = xy_range_str(input$plot_brush)
  
  validate(
    need(selected != "NULL", "Click and drag to select data")
  )
  

  paste0(
    "Selected Range: xmin=", selected[1], " xmax=", selected[2], 
         " ymin=", selected[3], " ymax=", selected[4])

})



output$stats = renderTable(
{
  
  selected = xy_range_str(input$plot_brush)
  
  
  df <- values()
  var1 <- input$pheno1
  var2 <- input$pheno2
  names(df)[grep("Phenotype",names(df))] <- "variable"
  df <- cast(df)


  
  selected = xy_range_str(input$plot_brush)
  left = selected[1]
  right = selected[2]
  top = selected[3]
  bot = selected[4]
  
  x = df[,var1]
  y = df[,var2]

  xindex = which(x > left & x < right )
  yindex = which(y < bot & y > top)
  bothindex = which(xindex %in% yindex)
  
  df = df[xindex[bothindex],]
#   if(ncol(df) == 4)
#     numSamples = 0

  validate(
    need(selected != "NULL" & ncol(df) > 4, "")
    )

  
  phenoOneValues = as.data.frame(df[,5])
  phenoTwoValues = as.data.frame(df[,4])
  # NEW CODE  
  numSamples = nrow(phenoOneValues)
  

  

  

    allTreats = c('control','highwater','osmocote')
    treats = df$Treatment
    treatPercent = c()
    for (i in 1:length(allTreats)) {
      treatPercent[i] = (length(which(treats==allTreats[i])) / numSamples) * 100
    }
    
    
    phenoOneMin = range(phenoOneValues)[1]
    phenoOneMax = range(phenoOneValues)[2]
    phenoOneMean = mean(df[,5])
    phenoOneStanD = sd(df[,5])
    phenoOneName = input$pheno1
    
    phenoTwoMin = range(phenoTwoValues)[1]
    phenoTwoMax = range(phenoTwoValues)[2]
    phenoTwoMean = mean(df[,4])
    phenoTwoStanD = sd(df[,4])
    phenoTwoName = input$pheno2
    
    stats = range(phenoOneValues)
    
    stats = data.frame(numSamples, phenoOneMin, phenoOneMean, phenoOneMax, phenoOneStanD, phenoTwoMin, phenoTwoMean, phenoTwoMax, phenoTwoStanD, treatPercent[1],treatPercent[2],treatPercent[3])
    names(stats) = c('Number of Samples',paste(phenoOneName,'Min'),paste(phenoOneName,'Mean'), paste(phenoOneName,'Max'), paste(phenoOneName,'Standard Deviation'),paste(phenoTwoName,'Min'),paste(phenoTwoName,'Mean'), paste(phenoTwoName,'Max'), paste(phenoTwoName,'Standard Deviation'),paste('Percent',allTreats[1]),paste('Percent',allTreats[2]),paste('Percent',allTreats[3]))
    
  
    stats

})

output$correlation = renderText({
  df <- values()
  var1 <- input$pheno1
  var2 <- input$pheno2
  names(df)[grep("Phenotype",names(df))] <- "variable"
  df <- cast(df)
  
  
  
  selected = xy_range_str(input$plot_brush)
  left = selected[1]
  right = selected[2]
  top = selected[3]
  bot = selected[4]
  
  x = df[,var1]
  y = df[,var2]
  
  xindex = which(x > left & x < right )
  yindex = which(y < bot & y > top)
  bothindex = which(xindex %in% yindex)
  
  df = df[xindex[bothindex],]
  
  validate(
    need(  ncol(df) > 4, "Select Different Phenotypes to see a Correlation")
  ) 
  
  validate(
    need(selected != "NULL", "No Data Selected")
  ) 
  

  

    cor = cor(df[,4:5])
    cor = cor[2]
    cor = round(cor, 4)
    cor = toString(cor)
    cor = paste('Corelation Between Selected Samples:',cor, sep=' ')
    
    cor
})
 
 output$linktable <- renderText(
     {
         
         var1 <- input$pheno1
         var2 <- input$pheno2

         df <- values()
         names(df)[grep("Phenotype",names(df))] <- "variable"
         df <- cast(df)
         selected = xy_range_str(input$plot_brush)
         
         validate(
           need(selected != "NULL", "Please select data to see individual lines")
         )
         
         left = selected[1]
         right = selected[2]
         top = selected[3]
         bot = selected[4]

         x = df[,var1]
         y = df[,var2]
         
         xindex = which(x > left & x < right )
         yindex = which(y < bot & y > top)
         bothindex = which(xindex %in% yindex)
         
         df = df[xindex[bothindex],]
         makeHTMLtable(df,session)

     })

# output$linktable2 <- renderTable(
# {
# 
# 
#   df <- values()
#   
#   selected = xy_range_str(input$plot_brush)
#   validate(
#     need(selected != "NULL", "Please select `data")
#   )
#   
#   var1 <- input$pheno1
#   var2 <- input$pheno2
#   names(df)[grep("Phenotype",names(df))] <- "variable"
#   df <- cast(df)
# 
#   left = selected[1]
#   right = selected[2]
#   top = selected[3]
#   bot = selected[4]
#   
#   x = df[,var1]
#   y = df[,var2]
#   
#   xindex = which(x > left & x < right )
#   yindex = which(y < bot & y > top)
#   bothindex = which(xindex %in% yindex)
#   
#   df = df[xindex[bothindex],]
#   data.frame(df)
# })

 output$downloadData <- downloadHandler(
                                        filename = function() {
                                          paste("phenorange",Sys.Date(),".csv",sep="")
                                        },
                                        content = function(file) {
                                          df <- values()
                                          var1 <- unique(df$Phenotype)[1]
                                          var2 <- var1
                                          if ((length(unique(df$Phenotype)))>1) {var2 <- unique(df$Phenotype)[2]}
                                          names(df)[2] <- "variable"
                                          ndf <- cast(df)
                                          ndf <- ndf[complete.cases(cbind(ndf[,c(var1,var2)])),]
                                          
                                          selected = xy_range_str(input$plot_brush)
                                          left = selected[1]
                                          right = selected[2]
                                          top = selected[3]
                                          bot = selected[4]
                                          
                                          ndf <- ndf[(ndf[,var1]>=left)&(ndf[,var1]<=right),]
                                          ndf <- ndf[(ndf[,var2]>=bot)&(ndf[,var2]<=top),]
                                          write.csv(file=file,ndf)
                                        }
                                        )
 
})
