#Partial Authorship by Nick Levitt
source("global.R")
library(ggplot2)

con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
#get some phenotype names
phenotbl <- dbGetQuery(con,"SELECT * FROM Phenotype")
#the next line only allow for experiments with phenotypes
expttbl <- unique(dbGetQuery(con,"SELECT E.name FROM Experiment E JOIN IndividualPlant IP ON IP.Experiment_idExperiment = E.idExperiment JOIN Observation O ON IP.idIndividualPlant = O.IndividualPlant_idIndividualPlant"))
treattbl <- dbGetQuery(con,"SELECT * FROM Treatment")
phenoname <- phenotbl$name
phenoname <- phenoname[!(phenoname%in%phenotypes.to.exclude)]
phenoname <- c(phenoname[which(phenoname=="fruitnum")],phenoname[-which(phenoname=="fruitnum")])


treatname <- treattbl$name
treatname <- c(treatname[which(treatname=="control")],treatname[-which(treatname=="control")])
dbDisconnect(con)

# NEW UI WITH NAVBAR
shinyUI(navbarPage("Phenotype Explore", 
                   tabPanel("Scatter Plot",
                          sidebarLayout(
                              sidebarPanel(
                                selectInput("pheno1", "Choose phenotype 1:", 
                                            choices = phenoname),
                                
                                selectInput("pheno2", "Choose phenotype 2:", 
                                            choices = phenoname),
                                
                                uiOutput('experiments'),
                                
                                selectInput("treat", "Choose a treatment:", 
                                            choices = c("All",treatname))

                              ),                              
                              
                              #Render the results
                              mainPanel(
                                textOutput("msg"),
                                textOutput("debug"),  
                                downloadLink('downloadData','Download CSV of selection'),
                                tabPanel("Phenotypic Distribution", 
                                           plotOutput("scatter", brush = "plot_brush"),
                                           h3(verbatimTextOutput('displaySelectInfo')),
                                           textOutput('SelectInfo'),
                                           textOutput('SelectInfo2'),
                                           h3(textOutput('correlation')),
                                           h3("Simple Statistics"),
                                           div(tableOutput("stats"), style = "font-size:80%")
                                         )                            
                              )
                            )           
                   ),
                   
                   tabPanel("Lines",
                            htmlOutput('linktable')
                   )                   
                   )
        )


