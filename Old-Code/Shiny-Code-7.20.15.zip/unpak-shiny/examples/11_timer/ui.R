shinyUI(bootstrapPage(
  textOutput("currentTime")
))