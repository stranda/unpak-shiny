source("../global.R")
library(ggplot2)


#### Define server logic required to summarize and view the selected dataset
shinyServer(function(input, output, session) {
  
  allData <- reactive({
    
    cdata <- session$clientData
    tmp <- strsplit(cdata$url_search,"&")[[1]]
    tmp <- tmp[grep("line",tmp)]
    if(length(tmp)>0) {
      url_line=strsplit(tmp,"=")[[1]][2]
      updateTextInput(session=session,inputId="line",value=url_line)
    }
    
    con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
    lines <- unique(dbGetQuery(con,"SELECT idAccession FROM Accession"))
    if (toupper(input$line) %in% lines$idAccession) #this tests the text input against the db before running query (insulate from sql inject)
    {
      query <- paste("SELECT O.value, Ph.name, Pl.Accession_idAccession, T.name, E.name, F.name, Pl.idIndividualPlant",
                     " FROM Observation O",
                     " JOIN IndividualPlant Pl ON O.IndividualPlant_idIndividualPlant = Pl.idIndividualPlant",
                     " JOIN Phenotype Ph ON O.Phenotype_idPhenotype = Ph.idPhenotype",
                     " JOIN Experiment E ON Pl.Experiment_idExperiment = E.idExperiment",
                     " JOIN Facility F ON F.idFacility = Pl.Facility_idFacility",
                     " JOIN Treatment T ON O.Treatment_idTreatment = T.idTreatment",
                     " WHERE Pl.Accession_idAccession = '",toupper(input$line),"'",
                     sep="")
      
      obstbl <- dbGetQuery(con,query)
      names(obstbl) <- c("value","phenotype","line","treatment","experiment","facility","individualPlant")

      udf <- unique(obstbl[obstbl$line==input$line,c("experiment","phenotype","treatment")])
      obstbl <- merge(obstbl,udf)
      
      if (dim(obstbl)[1]>0)
      {
        ret <- obstbl
        ret <- ret[complete.cases(ret),]
      } else {
        ret <- NULL
      }
    } else {
      ret <- NULL
    }
    cons<-dbListConnections(MySQL())
    for(con in cons)
      dbDisconnect(con) 
    ret
  })
  
  output$phenos = renderUI({
    df = allData()
    
    poss = sort(unique(df$phenotype))
    
    selectInput("phenos", "Choose a phenotype:", 
                choices = c(poss),selected = poss[1])  
  })
  
#   output$expts = renderUI({
#     df = allData()
#     df = df[which(df$phenotype == input$phenos),]
#     poss = sort(unique(df$experiment))
#     
#     selectInput("expts", "Choose an experiment:", 
#                 choices = c("All",poss), selected = 'All')  
#   })
#   
#   output$treats = renderUI({
#     df = allData()
#     if (input$expts != "All")
#       df = df[which(df$phenotype == input$phenos & df$experiment == input$expts),]
#     else
#       df = df[which(df$phenotype == input$phenos),]
#     
#     poss = sort(unique(df$treatment))
#     
#     selectInput("treats", "Choose a treatment:", 
#                 choices = c("All",poss),selected = 'All')  
#   })
  
  
  
  values <- reactive({
    
    cdata <- session$clientData
    tmp <- strsplit(cdata$url_search,"&")[[1]]
    tmp <- tmp[grep("line",tmp)]
    if(length(tmp)>0) {
      url_line=strsplit(tmp,"=")[[1]][2]
      updateTextInput(session=session,inputId="line",value=url_line)
    }
    
    con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
    lines <- unique(dbGetQuery(con,"SELECT idAccession FROM Accession"))
#     if (input$expts=="All"){expt=" "} else {expt=paste0(" E.name = '",input$expts,"' AND")}
#     if (input$treats=="All"){treat=" "} else {treat=paste0(" T.name = '",input$treats,"' AND")}
    if (toupper(input$line) %in% lines$idAccession) #this tests the text input against the db before running query (insulate from sql inject)
    {
      query <- paste("SELECT O.value, Ph.name, Pl.Accession_idAccession, T.name, E.name, F.name, Pl.idIndividualPlant",
                     " FROM Observation O",
                     " JOIN IndividualPlant Pl ON O.IndividualPlant_idIndividualPlant = Pl.idIndividualPlant",
                     " JOIN Phenotype Ph ON O.Phenotype_idPhenotype = Ph.idPhenotype",
                     " JOIN Experiment E ON Pl.Experiment_idExperiment = E.idExperiment",
                     " JOIN Facility F ON F.idFacility = Pl.Facility_idFacility",
                     " JOIN Treatment T ON O.Treatment_idTreatment = T.idTreatment",
                     " WHERE Ph.name = '", input$phenos, "' AND",
                     " Pl.Accession_idAccession = '",toupper(input$line),"'",
                     sep="")
      
      obstbl <- dbGetQuery(con,query)
      names(obstbl) <- c("value","phenotype","line","treatment","experiment","facility","individualPlant")
      udf <- unique(obstbl[obstbl$line==input$line,c("experiment","phenotype","treatment")])
      obstbl <- merge(obstbl,udf)
      
      if (dim(obstbl)[1]>0)
      {
        ret <- obstbl
        ret <- ret[complete.cases(ret),]
      } else {
        ret <- NULL
      }
    } else {
      ret <- NULL
    }
    dbDisconnect(con)
    ret
  })
     
    output$msg <- renderText({
         url.root <- "http://arabidopsis.org/servlets/Search?type=germplasm&search_action=search&pageNum=1&search=Submit+Query&germplasm_type=individual_line&taxon=1&name_type_1=gene_name&method_1=2&name_1=&name_type_2=germplasm_phenotype&method_2=1&name_2=&name_type_3=germplasm_stock_name&method_3=4&name_3="
         df <- allData()
         if (is.null(df))
             {
                 paste("This line",input$line,"is not in the db  Try another one")
             } else {
                 HTML(paste0("Go to TAIR for Line: <a href='",url.root,input$line,"' target='_blank'>",input$line,"</a>"))
                 
             }
     })
 
output$overview = renderDataTable({
  values()
} , options = list(lengthMenu = c(50, 100, 500), pageLength = 50))

buildHist = function(df) {
    ggplot(data = df, aes(value, fill = treatment)) + 
      geom_histogram(binwidth = input$bins) + geom_rug() +
      facet_wrap(~ experiment + treatment, scales = 'free')
}

output$hist = renderPlot({
  
  data = values()
  data2 = allData()
  buildHist(data)


  
})

# output$hist = renderPlot({
#   df = values()
#   if (input$correct=="all")
#   {
#     mns <- with(df,aggregate(cbind(mn.value=value),by=list(phenotype=phenotype,facility=facility),mean,na.rm=T))
#     tmp <- merge(df,mns)
#     df <- tmp[,1:5]
#     df$value=tmp$value-tmp$mn.value
#   }
#   else    if (input$correct=="phyt")
#   {
#     phydf <- df[grep("CS",df$line),] #if they start in CS, we call em phytometers
#     mns <- with(phydf,aggregate(cbind(mn.value=value),by=list(phenotype=phenotype,facility=facility),mean,na.rm=T))
#     tmp <- merge(df,mns)
#     df <- tmp[,1:5]
#     df$value=tmp$value-tmp$mn.value
#   }
# 
# 
#   title = paste('Distribution of ', input$phenos, " for line ", input$line, ':\n experiment = ', 
#                 input$expts, ", treatment = ", input$treats, sep = "")
#   ggplot(df, aes(value)) + geom_histogram(binwidth = 1, aes(fill = treatment)) + ggtitle(title)
# 
#   
# })





 output$downloadData <- downloadHandler(
                                        filename = function() {
                                          paste("linedata",Sys.Date(),".csv",sep="")
                                        },
                                        content = function(file) {
                                          df <- values()
                                          df <- unique(df[df$line==toupper(input$line),
                                                          c("line","individualPlant","phenotype","experiment","treatment","facility","value")])
                                          names(df)[3] <- "variable"
                                          ndf <- cast(df)
                                          write.csv(file=file,ndf)
                                        }
                                        )
    
 output$downloadPDF <- downloadHandler(
          
                                        filename = function() {
                                          paste("linePDF",Sys.Date(),".pdf",sep="")
                                        },
                                        content = function(file) {
                                          data <- values()

                                          pdf(file)
                                          buildHist(data)  
                                          dev.off()
                                        }
                                        )
    

  })
