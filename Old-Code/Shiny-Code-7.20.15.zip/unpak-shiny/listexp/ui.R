source("global.R")

# Define UI for dataset viewer application
shinyUI(
        fluidPage(theme="bootstrap.css",
                  titlePanel("Experiments in unPAK database"),
                  htmlOutput("linktable")
                  )
        )
