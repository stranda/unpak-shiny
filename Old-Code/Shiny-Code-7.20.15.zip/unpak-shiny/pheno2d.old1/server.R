source("global.R")

plotrect <- function(l,r,t,b, col=1, tail=TRUE)
    {
        if (tail)
            {
                abline(v=l,col="green",lwd=1)
                abline(v=r,col="red",lwd=1)
                abline(h=t,col="blue",lwd=1)
                abline(h=b,col="brown",lwd=1)
            }
        rect(xleft=l,xright=r,ytop=t,ybot=b,lwd=2,border=col)
    }


makeHTMLtable <- function (df)
{
    url.root.old <- "http://arabidopsis.org/servlets/Search?type=germplasm&search_action=search&pageNum=1&search=Submit+Query&germplasm_type=individual_line&taxon=1&name_type_1=gene_name&method_1=2&name_1=&name_type_2=germplasm_phenotype&method_2=1&name_2=&name_type_3=germplasm_stock_name&method_3=4&name_3="
    url.root.cloud <- "http://172.245.61.151:3838/findline/?line="
    url.root <- "http://107.170.146.165:3838/findline/?line="
    df$Accession <- paste0("<a href='",url.root,df$Accession,"' target='_blank'>",df$Accession,"</a>")
    cols <- dim(df)[2]
    rows <- dim(df)[1]
    for (j in 1:cols)
        {
            if (is.numeric(df[,j])) df[,j] <- as.character(round(df[,j],3))
            if (is.factor(df[,j])) df[,j] <- as.character(df[,j],3)
        }

    str <- "<table border = 1>"
    str <- paste0(str,"<tr><th>",paste(names(df),collapse="</th><th>"),"</tr>\n")
    for (i in 1:rows) {
      str <- paste0(str, "<tr><td>",paste(df[i,],collapse="</td><td>"),"</tr>\n")
    }
    str    
}


#### Define server logic required to summarize and view the selected dataset
shinyServer(function(input, output) {

 values <- reactive({
   if (input$expt=="All"){expt=" "} else {expt=paste0(" E.name = '",input$expt,"' AND")}

   if (input$treat=="All"){treat=" "} else {treat=paste0(" T.name = '",input$treat,"' AND")}
     con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
     query <- paste("SELECT O.value, Pl.Accession_idAccession, T.name, E.name, F.Name, Ph.name FROM Observation O",
                    " JOIN IndividualPlant Pl ON O.IndividualPlant_idIndividualPlant = Pl.idIndividualPlant",
                    " JOIN Phenotype Ph ON O.Phenotype_idPhenotype = Ph.idPhenotype",
                    " JOIN Experiment E ON Pl.Experiment_idExperiment = E.idExperiment",
                    " JOIN Treatment T ON O.Treatment_idTreatment = T.idTreatment",
                    " JOIN Facility F ON Pl.Facility_idFacility = F.idFacility",
                    " WHERE",
                    expt,
                    treat,
                    " (Ph.name = '",input$pheno1,"'  OR Ph.name = '",input$pheno2,"')",
                    sep="")

     obstbl <- dbGetQuery(con,query)
     names(obstbl) <- c("value","Accession","treatment","experiment","facility","phenotype")
     if (dim(obstbl)[1]>0)
         {
#             if (input$linemeans=="yes")
             if (TRUE)
                 {
                     ret <- with(obstbl,aggregate(cbind(value),by=list(Accession=Accession,Treatment=treatment,Experiment=experiment,Phenotype=phenotype),mean))
                     ret <- ret[order(ret$value),c("value","Phenotype","Experiment","Treatment","Accession")]
                 } else {
                     ret <- obstbl
                     ret$Treatment=ret$treatment
                     ret$Experiment=ret$experiment
                     ret$Facility=ret$facility
                     ret$Phenotype=ret$phenotype
                     ret <- ret[order(ret$Accession,ret$Experiment,ret$Treatment,ret$Facility),c("value","Phenotype","Treatment","Experiment","Facility","Accession")]
                   }
             ret <- ret[complete.cases(ret),]

         } else {
             ret <- NULL  #data.frame(value=NA,Phenotype=NA,Treatment=NA,Experiment=NA,Accession=NA)
         }
     dbDisconnect(con)
     ret
  })
  
 output$msg <- renderText(
     {
         df <- values()
         if (dim(df[complete.cases(df),])[1]==0)
             {
                 paste("This combination of experiment (",input$expt,"), phenotypes (",input$pheno1,", ",input$pheno2,") and/or treatment (",input$treat,") does not exist in the database.  Try another combination")
             } else {
                 paste("Experiment (",input$expt,"), Phenotypes (",input$pheno1,", ",input$pheno2,"), Treatment (",input$treat,")")
             }
     })
 

 output$scatter <- renderPlot(
     {
         df <- values()
         var1 <- input$pheno1
         var2 <- input$pheno2
         names(df)[grep("Phenotype",names(df))] <- "variable"
         df <- cast(df)
       
         left <- (abs(diff(range(df[,var1],na.rm=T)))*input$rangex[1])+min(df[,var1],na.rm=T)
         right <- (abs(diff(range(df[,var1],na.rm=T)))*input$rangex[2])+min(df[,var1],na.rm=T)
         
         top <- (abs(diff(range(df[,var2],na.rm=T)))*input$rangey[1])+min(df[,var2],na.rm=T)
         bot <- (abs(diff(range(df[,var2],na.rm=T)))*input$rangey[2])+min(df[,var2],na.rm=T)


         
         plot(x=df[,var1],y=df[,var2],main=paste(round(c(left,right,top,bot),2)), #paste0("Exp:",input$expt,", Treat:",input$treat),
              xlab=var1,ylab=var2)
         
         plotrect(left,right,top,bot)

     })
 
 output$linktable <- renderText(
     {
         
         var1 <- input$pheno1
         var2 <- input$pheno2

         df <- values()
         names(df)[grep("Phenotype",names(df))] <- "variable"
         df <- cast(df)
       
         left <- (abs(diff(range(df[,var1],na.rm=T)))*input$rangex[1])+min(df[,var1],na.rm=T)
         right <- (abs(diff(range(df[,var1],na.rm=T)))*input$rangex[2])+min(df[,var1],na.rm=T)
         
         top <- (abs(diff(range(df[,var2],na.rm=T)))*input$rangey[1])+min(df[,var2],na.rm=T)
         bot <- (abs(diff(range(df[,var2],na.rm=T)))*input$rangey[2])+min(df[,var2],na.rm=T)


#         df <- df[(df[,var1]>=left)&(df[,var1]<=right),]
#         df <- df[(df[,var2]>=bot)&(df[,var2]<=top),]
         makeHTMLtable(df)
     })

 output$downloadData <- downloadHandler(
                                        filename = function() {
                                          paste("phenorange",Sys.Date(),".csv",sep="")
                                        },
                                        content = function(file) {
                                          df <- values()
                                          var1 <- unique(df$Phenotype)[1]
                                          var2 <- var1
                                          if ((length(unique(df$Phenotype)))>1) {var2 <- unique(df$Phenotype)[2]}
                                          names(df)[2] <- "variable"
                                          ndf <- cast(df)
                                          ndf <- ndf[complete.cases(cbind(ndf[,c(var1,var2)])),]
                                          
                                          left <- (abs(diff(range(ndf[,var1])))*input$rangex[1])+min(ndf[,var1])
                                          right <- (abs(diff(range(ndf[,var1])))*input$rangex[2])+min(ndf[,var1])
                                          
                                          top <- (abs(diff(range(ndf[,var2])))*input$rangey[1])+min(ndf[,var2])
                                          bot <- (abs(diff(range(ndf[,var2])))*input$rangey[2])+min(ndf[,var2])
                                          
                                          ndf <- ndf[(ndf[,var1]>=left)&(ndf[,var1]<=right),]
                                          ndf <- ndf[(ndf[,var2]>=bot)&(ndf[,var2]<=top),]
                                          write.csv(file=file,ndf)
                                        }
                                        )
 
})
