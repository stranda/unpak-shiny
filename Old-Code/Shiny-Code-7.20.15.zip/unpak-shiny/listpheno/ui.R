source("global.R")

# Define UI for dataset viewer application
shinyUI(
        fluidPage(theme="bootstrap.css",
                  titlePanel("Phenotypes in unPAK database"),
                  htmlOutput("linktable")
                  )
        )
