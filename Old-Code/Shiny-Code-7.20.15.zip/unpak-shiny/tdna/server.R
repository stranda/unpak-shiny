source("global.R")
library(ggplot2)

makeHTMLtable <- function (df,session)
{
  #   url.root <- "http://107.170.146.165:3838/findline/?line="
  url.root = paste0(sep = '',"http://",session$clientData$url_hostname,":",
                    session$clientData$url_port,'/findline/?line=')
  df$Accession <- paste0("<a href='",url.root, df$Accession, "' target='_blank'>",df$Accession,"</a>")
  cols <- dim(df)[2]
  rows <- dim(df)[1]
  for (j in 1:cols)
  {
    if (is.numeric(df[,j])) df[,j] <- as.character(round(df[,j],3))
    if (is.factor(df[,j])) df[,j] <- as.character(df[,j],3)
  }
  
  str <- "<table border = 1>"
  str <- paste0(str,"<tr><th>",paste(names(df),collapse="</th><th>"),"</tr>\n")
  for (i in 1:rows) {
    str <- paste0(str, "<tr><td>",paste(df[i,],collapse="</td><td>"),"</tr>\n")
  }
  str    
}


#### Define server logic required to summarize and view the selected dataset
shinyServer(function(input, output,session) {

 values <- reactive({
     con <- dbConnect(MySQL(),dbname="unpak",user="unpak-R",password="thaliana")
     query <- paste("SELECT * FROM TDNARatio",
                    sep="")

     obstbl <- dbGetQuery(con,query)
     names(obstbl)[1] <- "Accession"
     dbDisconnect(con)
     obstbl <- obstbl[,-dim(obstbl)[2]]
     obstbl
  })
  
 output$msg <- renderText(
     {
         df <- values()
         if (dim(df[complete.cases(df),])[1]==0)
             {
               "No data in TDNARatio table"
             } else {
               paste (dim(df)[1],"lines with TDNA ratio data")
             }
     })
 
 output$hist <- renderPlot(
     {
         df <- values()

         left <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[1])+min(log(df$AreaRatio,base=10))
         right <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[2])+min(log(df$AreaRatio,base=10))

#          hist(log(base=10,df$AreaRatio),xlab="log10(Ratio)",main=paste0("Distribution of end-point pcr ratios TDNA/PetC"))
#          rug(log(df$AreaRatio,base=10))
#          abline(v=left,col="green",lwd=2)
#          abline(v=right,col="red",lwd=2)
        pheno = input$Phenotype
        xxx = ggplot(data = df, aes(log(base = 10,AreaRatio)))
        xxx + geom_histogram() + geom_rug() + 
        geom_vline(xintercept=left,  colour='red',
             linetype="dashed", size=1) +
        geom_vline(xintercept=right,  colour='blue',
             linetype="dashed", size=1)
     })

output$selectHist = renderPlot({
  df <- values()
  
  left <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[1])+min(log(df$AreaRatio,base=10))
  right <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[2])+min(log(df$AreaRatio,base=10))
#   left <- (abs(diff(range(df$AreaRatio)))*input$range[1])+min(df$AreaRatio)
#   right <- (abs(diff(range(df$AreaRatio)))*input$range[2])+min(df$AreaRatio)

  
  df <- df[(log(df$AreaRatio,base=10)>=left)&(log(df$AreaRatio,base=10)<=right),]

validate(
  need(nrow(df) > 0, "Please select data using the sliders on the left")
)
  
  xxx = ggplot(data=df,aes(log(base = 10,AreaRatio)))
  xxx + geom_histogram() + geom_rug()
  
  
})

 output$linktable <- renderText(
     {
         df <- values()

         left <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[1])+min(log(df$AreaRatio,base=10))
         right <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[2])+min(log(df$AreaRatio,base=10))

         df <- df[(log(df$AreaRatio,base=10)>=left)&(log(df$AreaRatio,base=10)<=right),]
         makeHTMLtable(df,session)
     })

 output$stats = renderTable ({
   df = values()
   left <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[1])+min(log(df$AreaRatio,base=10))
   right <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[2])+min(log(df$AreaRatio,base=10))
   df <- df[(log(df$AreaRatio,base=10)>=left)&(log(df$AreaRatio,base=10)<=right),]
   
   validate(
     need(nrow(df) > 0, "Please select data using the sliders on the left")
   )
   numSamples = nrow(df)
   avgEndo = mean(df[,3])
   avgTDNA = mean(df[,4])
   avgRatio = mean(df[,5])
   
   statistics = data.frame(numSamples,avgEndo,avgTDNA,avgRatio)
    names(statistics) = c('Num Samples', 'Avg EndoArea', 'Avg TDNAArea', 'Avg AreaRatio')
   
   statistics

   
 })

 output$downloadData <- downloadHandler(
                                        filename = function() {
                                          paste("TDNARange",Sys.Date(),".csv",sep="")
                                        },
                                        content = function(file) {
                                          df <- values()
                                          left <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[1])+min(log(df$AreaRatio,base=10))
                                          right <- (abs(diff(range(log(df$AreaRatio,base=10))))*input$range[2])+min(log(df$AreaRatio,base=10))
                                          
                                          df <- df[(log(df$AreaRatio,base=10)>=left)&(log(df$AreaRatio,base=10)<=right),]

                                          write.csv(file=file,df)
                                        }
                                        )
 
})


