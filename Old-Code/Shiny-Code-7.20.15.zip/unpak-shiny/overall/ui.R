source("global.R")


# Define UI for dataset viewer application
shinyUI(
#pageWithSidebar(
  fluidPage(theme="bootstrap.css",
  # Application title
            titlePanel("Current counts of objects in unPAK database"),
            htmlOutput("linktable")
      )
  )
